<?php
session_start(); // Inicia o reanuda la sesión del usuario
include 'dbase.php'; // Incluye el archivo de conexión a la base de datos
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="styles.css">
  <title>Hotel Kirk</title>
</head>
<header>
<?php
// Verifica si hay una sesión de usuario activa
if (isset($_SESSION['usuario'])) {
    // Muestra el nombre del usuario logueado y el botón de Cerrar Sesión
    echo '<div class="d-flex align-items-center gap-2">'
       . '<span class="mb-0">usuario: ' . htmlspecialchars($_SESSION['usuario']) . '</span> ' // Muestra el nombre del usuario escapando caracteres especiales
       . '<a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>';
    echo '</div>';
} else {
    // Si no hay sesión, muestra los botones de Registrarse e Iniciar Sesión
    echo '<a class="btn btn-primary" href="register.php">Registrarse</a> '
       . '<a class="btn btn-success" href="login.php">Iniciar Sesión</a>';
}
?>
</header>

<body>
  <?if (!empty($_SESSION['rol']) && $_SESSION['rol'] == 'admin') echo ?><a class="btn btn-warning" href="admin.php">Panel de Administrador</a><?;?>
<h1>Bienvenido a Nuestro Hotel</h1>

<h2>Habitaciones Disponibles</h2>

<?php
// Consulta SQL para seleccionar solo las habitaciones con estado 'Disponible'
$sql = "SELECT * FROM habitaciones WHERE estado='Disponible'";
$res = $conexion->query($sql); // Ejecuta la consulta

// Recorre e imprime cada habitación disponible
while ($fila = $res->fetch_assoc()) {
    echo "<div class='card'>
            <h3>{$fila['tipo']}</h3>
            <p>Precio: {$fila['precio']}</p>
            <p>Capacidad: {$fila['capacidad']}</p>
          </div>";
}
?>
<br>
<a class="btn btn-primary" href="reserva.php">Reservar una Habitacion</a>
</body>
</html>