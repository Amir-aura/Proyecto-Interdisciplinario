<?php
include 'dbase.php'; // Incluye la conexión a la base de datos
session_start(); 

// NOTA: Esta lógica de verificación de sesión está incompleta sin session_start().
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'admin') {
    die("Acceso denegado"); // Deniega el acceso si no es admin
}

// Procesa el formulario si se ha enviado por el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // NOTA: La lógica para obtener el ID de la habitación a eliminar está faltando.
    // Los campos 'tipo', 'precio', 'capacidad' no son necesarios para la eliminación por ID.
    $tipo = $_POST['tipo'];
    $prize = $_POST['precio'];
    $capacity = $_POST['capacidad'];
    // Ejecuta la consulta de eliminación
    $conexion->query('DELETE FROM habitaciones WHERE id=?'); 
    
    header("Location: admin.php"); // Redirige al panel de administración
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="styles.css">
  <title>Panel de Administrador - HotelBrand</title>
</head>
   
<form method="POST">
  <div class='wrapper'>
  <input type="text" placeholder="Tipo" name="tipo" required>
  <input type="text" placeholder="Precio" name="precio" required>
  <input type="text" placeholder = "Capacidad" name="capacidad" required>
  <button type="submit">ELIMINAR Habitacion</button>
  </div> 
</form>


<body>
    
</body>
</html>