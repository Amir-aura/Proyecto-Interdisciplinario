<?php
// Establece una nueva conexión a la base de datos MySQL
// Parámetros: servidor, usuario, contraseña, nombre de la base de datos
$conexion = new mysqli("localhost", "root", "", "hotel_kirk");

// Verifica si la conexión falló
if ($conexion->connect_error) {
    // Detiene la ejecución del script y muestra un mensaje de error si la conexión es fallida
    die("Error de conexión: " . $conexion->connect_error);
}
// Si la conexión es exitosa, el script continúa
?>