<?php
// Función para verificar si un usuario tiene el rol de administrador
function es_admin($user_row) {
    // Comprueba si el array del usuario tiene la clave 'rol' y si su valor es estrictamente 'admin'
    return isset($user_row['rol']) && $user_row['rol'] === 'admin';
}

// Función para redirigir al usuario a una URL específica
function redirect($url) {
    // Envía el encabezado de HTTP 'Location' para la redirección
    header('Location: ' . $url);
    // Termina la ejecución del script para asegurar que la redirección ocurra inmediatamente
    exit;
}
?>