<?php
include 'dbase.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reserve') {
    $room_id = intval($_POST['room_id'] ?? 0);
    $fecha_salida_raw = trim($_POST['fecha_salida'] ?? '');

    if ($room_id <= 0) {
        $msg = 'ID de habitación inválido.';
    } elseif ($fecha_salida_raw === '') {
        $msg = 'Por favor indica la fecha de salida.';
    } else {
        try {
            $fecha_salida = new DateTime($fecha_salida_raw);
        } catch (Exception $e) {
            $fecha_salida = null;
        }

        if (! $fecha_salida) {
            $msg = 'Fecha de salida inválida.';
        } else {
            $today = new DateTime('today');
            if ($fecha_salida <= $today) {
                $msg = 'La fecha de salida debe ser posterior a hoy.';
            } else {
                $new_state = 'reservada';
                $expected = 'disponible';
                if ($stmt = $conexion->prepare("UPDATE habitaciones SET estado = ? WHERE ID = ? AND estado = ?")) {
                    $stmt->bind_param('sis', $new_state, $room_id, $expected);
                    $stmt->execute();

                    if ($stmt->affected_rows === 1) {
                        $stmt->close();
                        if ($ins = $conexion->prepare("INSERT INTO reservas (ID_Habitacion, fecha_entrada, fecha_salida) VALUES (?, NOW(), ?)")) {
                            $fecha_salida_str = $fecha_salida->format('Y-m-d');
                            $ins->bind_param('is', $room_id, $fecha_salida_str);
                            if ($ins->execute()) {
                                $conexion->commit();
                                $msg = 'Habitación reservada correctamente hasta ' . htmlspecialchars($fecha_salida_str) . '.';
                            } else {
                                $conexion->rollback();
                                $msg = 'Error al crear la reserva: ' . $ins->error;
                            }
                            $ins->close();
                        } else {
                            $conexion->rollback();
                            $msg = 'Error en consulta de reservas: ' . $conexion->error;
                        }
                    } else {
                        $conexion->rollback();
                        $msg = 'La habitación ya no está disponible.';
                        $stmt->close();
                    }
                } else {
                    $conexion->rollback();
                    $msg = 'Error en la consulta: ' . $conexion->error;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <title>Reservas - HotelBrand</title>
</head>
<body>
  <div class="container my-4">
    <?php if ($msg): ?>
      <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <a href="index.php" class="btn btn-primary">volve al menu</a>
    <h2 class="mb-3">Habitaciones disponibles</h2>

    <div class="row row-cols-1 row-cols-md-2 g-3">
      <?php
      if ($res = $conexion->query("SELECT ID,tipo, precio, capacidad FROM habitaciones WHERE estado = 'disponible'")) {
          while ($r = $res->fetch_assoc()):
              $id = (int)$r['ID'];
              $tipo = htmlspecialchars($r['tipo']);
              $precio = htmlspecialchars($r['precio']);
              $capacidad = htmlspecialchars($r['capacidad']);
      ?>
        <div class="col">
          <div class="card mb-3">
            <div class="row g-0 align-items-center">
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title"><?= $tipo ?></h5>
                  <p class="card-text mb-1">Precio: <?= $precio ?></p>
                  <p class="card-text mb-2">Capacidad: <?= $capacidad ?></p>

                  <form method="POST" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="action" value="reserve">
                    <input type="hidden" name="room_id" value="<?= $id ?>">

                    <input type="date" name="fecha_salida" class="form-control" required
                      min="<?= date('Y-m-d') ?>" aria-label="Fecha de salida">

                    <button type="submit" class="btn btn-primary">Reservar</button>
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>
      <?php
          endwhile;
          $res->free();
      } else {
          echo '<div class="alert alert-danger">Error al cargar habitaciones.</div>';
      }
      ?>
    </div>
  </div>
</body>
</html>