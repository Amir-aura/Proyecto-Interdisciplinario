<?php
include 'dbase.php'; // Incluye la conexión a la base de datos
$msg = ''; // Inicializa la variable para mensajes de error o éxito

// Procesa el formulario si se ha enviado por el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recupera, limpia y asigna los datos del formulario
    $usuario = trim($_POST['usuario'] ?? '');
    $clave = $_POST['clave'] ?? '';
    $email = trim($_POST['mail'] ?? '');

    // 1. Validar que todos los campos estén llenos
    if ($usuario === '' || $clave === '' || $email === '') {
        $msg = 'Todos los campos son obligatorios.';
    } else {
        // 2. Comprobar si el nombre de usuario ya existe
        if ($stmt = $conexion->prepare('SELECT id FROM usuarios WHERE usuario = ? LIMIT 1')) {
            $stmt->bind_param('s', $usuario);
            $stmt->execute();
            $stmt->store_result(); // Almacena el resultado para contar filas
            if ($stmt->num_rows > 0) {
                $msg = 'El usuario ya existe. Elige otro nombre.';
                $stmt->close();
            } else {
                $stmt->close();
                // 3. Comprobar si el correo electrónico ya está registrado
                if ($stmt2 = $conexion->prepare('SELECT id FROM usuarios WHERE mail = ? LIMIT 1')) {
                    $stmt2->bind_param('s', $email);
                    $stmt2->execute();
                    $stmt2->store_result();
                    if ($stmt2->num_rows > 0) {
                        $msg = 'El correo ya está registrado.';
                        $stmt2->close();
                    } else {
                        $stmt2->close();        
                        // 4. Registrar nuevo usuario
                        $pass = password_hash($clave, PASSWORD_DEFAULT); // Hashea la contraseña de forma segura
                        $rol = 'cliente'; // Asigna el rol por defecto
                        
                        // Sentencia preparada para insertar el nuevo usuario
                        if ($ins = $conexion->prepare("INSERT INTO usuarios(usuario, mail, password_hash, rol) VALUES(?, ?, ?, ?)")) {
                            $ins->bind_param('ssss', $usuario, $email, $pass, $rol); // 'ssss' indica 4 strings
                            if ($ins->execute()) {
                                $ins->close();
                                header("Location: login.php"); // Redirige a la página de login
                                exit;
                            } else {
                                $msg = 'Error al registrar: ' . $ins->error;
                                $ins->close();
                            }
                        } else {
                            $msg = 'Error en la base de datos: ' . $conexion->error;
                        }
                    }
                } else {
                    $msg = 'Error en la comprobación del correo: ' . $conexion->error;
                }
            }
        } else {
            $msg = 'Error en la base de datos: ' . $conexion->error;
        }
    }
}
?>


<!DOCTYPE html>

<head>
  <link rel="stylesheet" href="styles.css">
  <title>Create Your Account - HotelBrand</title>
</head>

<?php if ($msg): ?>
  <div class="alert"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<form method="POST">
  <div class='wrapper'>
  <input type="text" placeholder="Usuario" name="usuario" required>
  <input type="password" placeholder="Contraseña" name="clave" required>
  <input type="text" placeholder = "E-Mail" name="mail" required>
  <button type="submit">Registrarse</button>
  </div> 
</form>