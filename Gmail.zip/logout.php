<?php
session_start(); // Inicia la sesión
session_destroy(); // Destruye toda la información registrada en la sesión actual
header("Location: index.php"); // Redirige al usuario a la página principal
?>