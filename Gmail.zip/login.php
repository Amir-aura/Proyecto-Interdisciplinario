<?php 
include 'dbase.php'; // Incluye la conexión a la base de datos

// Procesa el formulario si se ha enviado por el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    
    // Consulta el usuario (vulnerable a inyección SQL ya que no usa prepared statements)
    $res = $conexion->query("SELECT * FROM usuarios WHERE usuario='$usuario'"); 
    
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        // Verifica la contraseña hasheada almacenada en la base de datos
        if (password_verify($clave, $row['password_hash'])) {
            session_start(); // Inicia la sesión
            // Almacena el nombre de usuario y el rol en variables de sesión
            $_SESSION['usuario'] = $row['usuario']; 
            $_SESSION['rol'] = $row['rol'];
            header("Location:index.php"); // Redirige a la página principal
            exit;
        }
    }
    // Muestra mensaje si las credenciales son incorrectas (si no hubo redirección)
    echo "Credenciales incorrectas";
}
?>


<!DOCTYPE html>

<head>
  <link rel="stylesheet" href="styles.css">
  <title>Create Your Account - Hotel KIRK</title>
</head>

    <a href="index.php" class="btn btn-primary">volve al menu</a>
<form method="POST">
  <div class='wrapper'>
  <input type="text" placeholder="Usuario" name="usuario" required>
  <input type="password" placeholder="Contraseña" name="clave" required>
  <button type="submit">Iniciar Sesion</button>
</div>
</form>