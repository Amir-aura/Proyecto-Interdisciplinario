<?php
include 'dbase.php'; // Incluye la conexión a la base de datos
session_start(); // Inicia la sesión

// Verifica si el usuario está logueado y si su rol es 'admin'
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'admin') {
    die("Acceso denegado"); // Si no es admin, deniega el acceso y detiene el script
}

// Procesa el formulario si se ha enviado por el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recupera y sanitiza (aunque se recomienda usar sentencias preparadas para esto) los datos del POST
    $tipo = $_POST['tipo'];
    $prize = $_POST['precio'];
    $capacity = $_POST['capacidad'];
    $estado = 'disponible' ; // Define el estado inicial de la nueva habitación
    
    // Ejecuta la consulta de inserción (vulnerable a inyección SQL ya que no usa prepared statements)
    $conexion->query("INSERT INTO habitaciones(tipo, precio, capacidad, estado) VALUES('$tipo', '$prize', '$capacity', '$estado')");
    
    header("Location: admin.php"); // Redirige al panel de administración después de la inserción
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="styles.css">
  <title>Panel de Administrador - HotelBrand</title>
</head>
   
<form method="POST">
  <div class='wrapper'>
  <input type="text" placeholder="Tipo" name="tipo" required>
  <input type="text" placeholder="Precio" name="precio" required>
  <input type="text" placeholder = "Capacidad" name="capacidad" required>
  <button type="submit">Agregar Habitacion</button>
  </div> 
</form>

<body>
    
</body>
</html>