<?php
// Archivo: admin.php
// Propósito: Panel de administración que lista todas las habitaciones y permite editarlas o agregar nuevas.
// Acceso: Solo usuarios logueados con rol 'admin'.

require 'dbase.php';
// Incluir archivo de conexión a la base de datos.

session_start();
// Iniciar sesión para acceder a $_SESSION['usuario'].

if (!isset($_SESSION['usuario'])) header('Location: index.php');
// Si no hay usuario en sesión, redirigir a la página de login (index.php).

// Verificar rol de administrador
$stmt = $conexion->prepare('SELECT id,rol,usuario FROM usuarios WHERE id=?');
// Preparar consulta para obtener rol del usuario actual desde la tabla usuarios.

$stmt->bind_param('i', $_SESSION['usuario']);
// Vincular el ID del usuario desde la sesión (tipo int 'i').

$stmt->execute();
// Ejecutar la consulta.

$user = $stmt->get_result()->fetch_assoc();
// Obtener el registro del usuario en un array asociativo.

if (!isset($_SESSION['rol']) && $_SESSION['rol'] !== 'admin') {
    // Comprobar si la sesión NO tiene 'rol' O el rol NO es 'admin'.
    // (Nota: hay un error lógico aquí: debería ser || en lugar de &&)
    header('Location:index.php');
    // Redirigir a index.php si no es admin.
    exit;
    // Detener el script.
}
?>
<!-- Encabezado del panel -->
<h1>Panel de Administración</h1>

<!-- Enlaces de navegación -->
<a href="agregar.php">Agregar Habitación</a>
<!-- Enlace para ir al formulario de agregar una nueva habitación. -->

<a href="logout.php">Cerrar Sesión</a>
<!-- Enlace para cerrar sesión y desloguear al usuario. -->

<!-- Título de la sección de habitaciones -->
<h2>Habitaciones</h2>

<?php
// Consultar todas las habitaciones desde la base de datos
$res = $conexion->query("SELECT * FROM habitaciones");
// Ejecutar consulta para obtener todas las filas de la tabla habitaciones.

while ($fila = $res->fetch_assoc()) {
    // Recorrer cada registro de habitaciones en un loop.
    
    // Pasar id_habitacion (o id) por GET al archivo UPDATE.php
    $id_habit = htmlspecialchars($fila['ID']);
    // Obtener el ID de la habitación y escapar HTML (seguridad).
    
    echo "{$fila['tipo']} - {$fila['precio']} - {$fila['estado']} "
       . "<a href='UPDATE.php?id=" . $id_habit . "'>Modificar</a><br>";
    // Mostrar: tipo, precio y estado de cada habitación, con un enlace a UPDATE.php pasando el ID por GET.
}
?>
